package com.example.imageserver.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import com.example.imageserver.R;

public final class ActivityMainBinding
implements ViewBinding {
    @NonNull
    private final CoordinatorLayout rootView;

    private ActivityMainBinding(@NonNull CoordinatorLayout rootView) {
        this.rootView = rootView;
    }

    @NonNull
    public CoordinatorLayout getRoot() {
        return this.rootView;
    }

    @NonNull
    public static ActivityMainBinding inflate(@NonNull LayoutInflater inflater) {
        return ActivityMainBinding.inflate(inflater, null, false);
    }

    @NonNull
    public static ActivityMainBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
        View root = inflater.inflate(R.layout.activity_main, parent, false);
        if (attachToParent) {
            parent.addView(root);
        }
        return ActivityMainBinding.bind(root);
    }

    @NonNull
    public static ActivityMainBinding bind(@NonNull View rootView) {
        if (rootView == null) {
            throw new NullPointerException("rootView");
        }
        return new ActivityMainBinding((CoordinatorLayout)rootView);
    }
}
