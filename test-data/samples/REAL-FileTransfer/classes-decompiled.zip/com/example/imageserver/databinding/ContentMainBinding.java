package com.example.imageserver.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.imageserver.R;

public final class ContentMainBinding
implements ViewBinding {
    @NonNull
    private final ScrollView rootView;
    @NonNull
    public final Button availabilityButton;
    @NonNull
    public final Button chooseFolderButton;
    @NonNull
    public final TextView folderText;
    @NonNull
    public final Button forgetButton;
    @NonNull
    public final LinearLayout peerList;
    @NonNull
    public final TextView statusText;
    @NonNull
    public final TextView titleText;
    @NonNull
    public final Button uploadButton;

    private ContentMainBinding(@NonNull ScrollView rootView, @NonNull Button availabilityButton, @NonNull Button chooseFolderButton, @NonNull TextView folderText, @NonNull Button forgetButton, @NonNull LinearLayout peerList, @NonNull TextView statusText, @NonNull TextView titleText, @NonNull Button uploadButton) {
        this.rootView = rootView;
        this.availabilityButton = availabilityButton;
        this.chooseFolderButton = chooseFolderButton;
        this.folderText = folderText;
        this.forgetButton = forgetButton;
        this.peerList = peerList;
        this.statusText = statusText;
        this.titleText = titleText;
        this.uploadButton = uploadButton;
    }

    @NonNull
    public ScrollView getRoot() {
        return this.rootView;
    }

    @NonNull
    public static ContentMainBinding inflate(@NonNull LayoutInflater inflater) {
        return ContentMainBinding.inflate(inflater, null, false);
    }

    @NonNull
    public static ContentMainBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
        View root = inflater.inflate(R.layout.content_main, parent, false);
        if (attachToParent) {
            parent.addView(root);
        }
        return ContentMainBinding.bind(root);
    }

    @NonNull
    public static ContentMainBinding bind(@NonNull View rootView) {
        Button uploadButton;
        TextView titleText;
        TextView statusText;
        LinearLayout peerList;
        Button forgetButton;
        TextView folderText;
        Button chooseFolderButton;
        int id2 = R.id.availabilityButton;
        Button availabilityButton = (Button)ViewBindings.findChildViewById((View)rootView, (int)id2);
        if (availabilityButton != null && (chooseFolderButton = (Button)ViewBindings.findChildViewById((View)rootView, (int)(id2 = R.id.chooseFolderButton))) != null && (folderText = (TextView)ViewBindings.findChildViewById((View)rootView, (int)(id2 = R.id.folderText))) != null && (forgetButton = (Button)ViewBindings.findChildViewById((View)rootView, (int)(id2 = R.id.forgetButton))) != null && (peerList = (LinearLayout)ViewBindings.findChildViewById((View)rootView, (int)(id2 = R.id.peerList))) != null && (statusText = (TextView)ViewBindings.findChildViewById((View)rootView, (int)(id2 = R.id.statusText))) != null && (titleText = (TextView)ViewBindings.findChildViewById((View)rootView, (int)(id2 = R.id.titleText))) != null && (uploadButton = (Button)ViewBindings.findChildViewById((View)rootView, (int)(id2 = R.id.uploadButton))) != null) {
            return new ContentMainBinding((ScrollView)rootView, availabilityButton, chooseFolderButton, folderText, forgetButton, peerList, statusText, titleText, uploadButton);
        }
        String missingId = rootView.getResources().getResourceName(id2);
        throw new NullPointerException("Missing required view with ID: ".concat(missingId));
    }
}
