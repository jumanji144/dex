package com.example.imageserver.transfer;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;
import com.example.imageserver.transfer.IdentityStore;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Locale;

public final class TransferFiles {
    private TransferFiles() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String displayName(Context context, Uri uri) {
        String string;
        ContentResolver resolver = context.getContentResolver();
        try (Cursor cursor2222 = resolver.query(uri, new String[]{"_display_name"}, null, null, null);){
            String name;
            if (cursor2222 != null && cursor2222.moveToFirst() && (name = cursor2222.getString(0)) != null && !name.trim().isEmpty()) {
                String string2 = TransferFiles.sanitizeName(name);
                return string2;
            }
        }
        catch (Exception cursor2222) {
            // empty catch block
        }
        String fallback = uri.getLastPathSegment();
        if (fallback == null) {
            string = "transferred-file";
            return TransferFiles.sanitizeName(string);
        }
        string = fallback;
        return TransferFiles.sanitizeName(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static long size(Context context, Uri uri) {
        try (Cursor cursor2222 = context.getContentResolver().query(uri, new String[]{"_size"}, null, null, null);){
            if (cursor2222 != null && cursor2222.moveToFirst() && !cursor2222.isNull(0)) {
                long l2 = cursor2222.getLong(0);
                return l2;
            }
        }
        catch (Exception cursor2222) {
            // empty catch block
        }
        try (InputStream input = TransferFiles.open(context, uri);){
            int count;
            byte[] buffer = new byte[65536];
            long total = 0L;
            while ((count = input.read(buffer)) != -1) {
                total += (long)count;
            }
            long l = total;
            return l;
        }
        catch (Exception ignored) {
            return -1L;
        }
    }

    public static String mimeType(Context context, Uri uri) {
        String type = context.getContentResolver().getType(uri);
        return type == null ? "application/octet-stream" : type;
    }

    public static String sha256(Context context, Uri uri) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = context.getContentResolver().openInputStream(uri);){
            int count;
            if (input == null) {
                throw new IllegalStateException("Unable to open selected file");
            }
            byte[] buffer = new byte[65536];
            while ((count = input.read(buffer)) != -1) {
                digest.update(buffer, 0, count);
            }
        }
        return IdentityStore.hex(digest.digest());
    }

    public static InputStream open(Context context, Uri uri) throws Exception {
        InputStream input = context.getContentResolver().openInputStream(uri);
        if (input == null) {
            throw new IllegalStateException("Unable to open selected file");
        }
        return input;
    }

    public static DocumentFile createTemp(Context context, Uri treeUri, String name, String mime) {
        DocumentFile tree = DocumentFile.fromTreeUri((Context)context, (Uri)treeUri);
        if (tree == null || !tree.canWrite()) {
            return null;
        }
        return tree.createFile(mime, "." + TransferFiles.sanitizeName(name) + ".part");
    }

    public static String uniqueName(DocumentFile tree, String name) {
        String clean = TransferFiles.sanitizeName(name);
        if (tree.findFile(clean) == null) {
            return clean;
        }
        int dot = clean.lastIndexOf(46);
        String base = dot > 0 ? clean.substring(0, dot) : clean;
        String extension = dot > 0 ? clean.substring(dot) : "";
        for (int i = 1; i < 10000; ++i) {
            String candidate = String.format(Locale.US, "%s (%d)%s", base, i, extension);
            if (tree.findFile(candidate) != null) continue;
            return candidate;
        }
        return clean + "-" + System.currentTimeMillis();
    }

    public static String sanitizeName(String name) {
        String value;
        String string = value = name == null ? "transferred-file" : name.replaceAll("[\\\\/:*?\"<>|\\r\\n]", "_").trim();
        if (value.length() == 0 || value.equals(".") || value.equals("..")) {
            value = "transferred-file";
        }
        return value.length() > 180 ? value.substring(0, 180) : value;
    }
}
