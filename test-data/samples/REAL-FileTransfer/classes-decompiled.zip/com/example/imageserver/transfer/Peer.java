package com.example.imageserver.transfer;

import java.net.InetAddress;
import java.util.Objects;

public final class Peer {
    private final String id;
    private final String name;
    private final InetAddress address;
    private final int port;
    private final boolean paired;

    public Peer(String id, String name, InetAddress address, int port, boolean paired) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.port = port;
        this.paired = paired;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public InetAddress getAddress() {
        return this.address;
    }

    public int getPort() {
        return this.port;
    }

    public boolean isPaired() {
        return this.paired;
    }

    public Peer withPaired(boolean value) {
        return new Peer(this.id, this.name, this.address, this.port, value);
    }

    public boolean equals(Object other) {
        if (!(other instanceof Peer)) {
            return false;
        }
        return this.id.equals(((Peer)other).id);
    }

    public int hashCode() {
        return Objects.hash(this.id);
    }

    public String toString() {
        return this.name + " (" + this.address.getHostAddress() + ")";
    }
}
