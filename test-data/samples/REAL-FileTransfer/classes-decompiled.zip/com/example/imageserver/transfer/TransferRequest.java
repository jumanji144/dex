package com.example.imageserver.transfer;

import android.net.Uri;
import com.example.imageserver.transfer.Peer;

public final class TransferRequest {
    private final String id;
    private final Peer peer;
    private final Uri source;
    private final String name;
    private final String mimeType;
    private final long size;
    private final String sha256;

    public TransferRequest(String id, Peer peer, Uri source, String name, String mimeType, long size, String sha256) {
        this.id = id;
        this.peer = peer;
        this.source = source;
        this.name = name;
        this.mimeType = mimeType;
        this.size = size;
        this.sha256 = sha256;
    }

    public String getId() {
        return this.id;
    }

    public Peer getPeer() {
        return this.peer;
    }

    public Uri getSource() {
        return this.source;
    }

    public String getName() {
        return this.name;
    }

    public String getMimeType() {
        return this.mimeType;
    }

    public long getSize() {
        return this.size;
    }

    public String getSha256() {
        return this.sha256;
    }
}
