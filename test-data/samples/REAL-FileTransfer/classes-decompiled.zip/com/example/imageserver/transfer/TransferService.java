package com.example.imageserver.transfer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.documentfile.provider.DocumentFile;
import com.example.imageserver.MainActivity;
import com.example.imageserver.R;
import com.example.imageserver.transfer.IdentityStore;
import com.example.imageserver.transfer.PairingStore;
import com.example.imageserver.transfer.Peer;
import com.example.imageserver.transfer.TransferFiles;
import com.example.imageserver.transfer.TransferObserver;
import com.example.imageserver.transfer.TransferProgress;
import com.example.imageserver.transfer.TransferProtocol;
import com.example.imageserver.transfer.TransferRequest;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class TransferService
extends Service {
    public static final String ACTION_START = "com.example.imageserver.transfer.START";
    public static final String ACTION_STOP = "com.example.imageserver.transfer.STOP";
    public static final String ACTION_CANCEL = "com.example.imageserver.transfer.CANCEL";
    public static final String EXTRA_TRANSFER_ID = "transfer_id";
    public static final String EXTRA_DESTINATION = "destination";
    public static final String SERVICE_TYPE = "_imageserver._tcp";
    private static final String TAG = "TransferService";
    private static final int NOTIFICATION_ID = 41;
    private static final String CHANNEL_ID = "transfer_availability";
    private static final int PAIRING_TIMEOUT_SECONDS = 120;
    private final IBinder binder = new LocalBinder();
    private final CopyOnWriteArrayList<TransferObserver> observers = new CopyOnWriteArrayList();
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<String, Peer> peers = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, String> servicePeerIds = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, Socket> activeSockets = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, Boolean> cancelledTransfers = new ConcurrentHashMap();
    private final Object lifecycleLock = new Object();
    private final ConcurrentHashMap<String, PendingPairing> pendingPairings = new ConcurrentHashMap();
    private IdentityStore identity;
    private PairingStore pairings;
    private String deviceId;
    private NsdManager nsdManager;
    private NsdManager.RegistrationListener registrationListener;
    private NsdManager.DiscoveryListener discoveryListener;
    private NsdServiceInfo registeredService;
    private ServerSocket serverSocket;
    private Thread acceptThread;
    private WifiManager.MulticastLock multicastLock;
    private volatile boolean available;
    private boolean starting;
    private SharedPreferences preferences;

    public void onCreate() {
        super.onCreate();
        this.identity = new IdentityStore((Context)this);
        this.pairings = new PairingStore((Context)this);
        this.preferences = this.getSharedPreferences("transfer_preferences", 0);
        this.nsdManager = (NsdManager)this.getSystemService("servicediscovery");
        this.createNotificationChannel();
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            this.stopAvailability();
            this.stopForeground(true);
            this.stopSelf();
            return 2;
        }
        if (intent != null && ACTION_CANCEL.equals(intent.getAction())) {
            this.cancelTransfer(intent.getStringExtra(EXTRA_TRANSFER_ID));
            return 2;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.startForeground(41, this.buildNotification("Available for file transfers"), 1);
        } else {
            this.startForeground(41, this.buildNotification("Available for file transfers"));
        }
        this.startAvailability();
        return 2;
    }

    @Nullable
    public IBinder onBind(Intent intent) {
        return this.binder;
    }

    public void onDestroy() {
        this.stopAvailability();
        this.workers.shutdownNow();
        super.onDestroy();
    }

    public void registerObserver(TransferObserver observer) {
        if (observer == null) {
            return;
        }
        this.observers.addIfAbsent(observer);
        observer.onAvailabilityChanged(this.available);
        this.notifyPeersTo(observer);
    }

    public void unregisterObserver(TransferObserver observer) {
        this.observers.remove(observer);
    }

    public boolean isAvailable() {
        return this.available;
    }

    public List<Peer> getPeers() {
        ArrayList<Peer> result = new ArrayList<Peer>(this.peers.values());
        Collections.sort(result, Comparator.comparing(Peer::getName, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void startAvailability() {
        Object object = this.lifecycleLock;
        synchronized (object) {
            if (this.available || this.starting) {
                return;
            }
            this.starting = true;
        }
        this.workers.execute(() -> {
            ServerSocket newServer = null;
            try {
                this.identity.ensureIdentity();
                this.deviceId = this.identity.deviceId();
                newServer = new ServerSocket(0);
                newServer.setSoTimeout(1000);
                Object object = this.lifecycleLock;
                synchronized (object) {
                    if (!this.starting) {
                        newServer.close();
                        return;
                    }
                    this.serverSocket = newServer;
                    this.starting = false;
                    this.available = true;
                }
                this.notifyAvailability(true);
                this.startNsd();
                this.acceptThread = new Thread(this::acceptLoop, "ImageServer accept");
                this.acceptThread.start();
            }
            catch (Throwable error) {
                Object object = this.lifecycleLock;
                synchronized (object) {
                    this.starting = false;
                }
                if (newServer != null) {
                    try {
                        newServer.close();
                    }
                    catch (IOException iOException) {
                        // empty catch block
                    }
                }
                Log.e((String)TAG, (String)"Unable to start transfer availability", (Throwable)error);
                this.available = false;
                this.notifyError("Could not become available: " + error.getMessage());
            }
        });
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void stopAvailability() {
        Iterator<Socket> iterator = this.lifecycleLock;
        synchronized (iterator) {
            if (!this.available && this.serverSocket == null && !this.starting) {
                return;
            }
            this.starting = false;
            this.available = false;
        }
        this.notifyAvailability(false);
        try {
            if (this.discoveryListener != null) {
                this.nsdManager.stopServiceDiscovery(this.discoveryListener);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            if (this.registrationListener != null) {
                this.nsdManager.unregisterService(this.registrationListener);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.discoveryListener = null;
        this.registrationListener = null;
        this.registeredService = null;
        if (this.multicastLock != null && this.multicastLock.isHeld()) {
            this.multicastLock.release();
        }
        this.multicastLock = null;
        try {
            if (this.serverSocket != null) {
                this.serverSocket.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.serverSocket = null;
        for (Socket socket : this.activeSockets.values()) {
            try {
                socket.close();
            }
            catch (Exception exception) {}
        }
        this.activeSockets.clear();
        this.peers.clear();
        this.servicePeerIds.clear();
        this.notifyPeers();
    }

    public void setDestinationTree(Uri uri) {
        if (uri == null) {
            return;
        }
        this.getContentResolver().takePersistableUriPermission(uri, 3);
        this.preferences.edit().putString("destination_tree", uri.toString()).apply();
    }

    @Nullable
    public Uri getDestinationTree() {
        String value = this.preferences.getString("destination_tree", null);
        return value == null ? null : Uri.parse((String)value);
    }

    public void sendFile(Peer peer, Uri source) {
        if (peer == null || source == null) {
            return;
        }
        String id = UUID.randomUUID().toString();
        this.publishProgress(new TransferProgress(id, TransferProgress.Direction.SEND, "Preparing", 0L, 0L, TransferProgress.State.PREPARING, null));
        this.workers.execute(() -> {
            try {
                long size = TransferFiles.size((Context)this, source);
                if (size < 0L) {
                    throw new IOException("The selected provider did not report a file size");
                }
                String name = TransferFiles.displayName((Context)this, source);
                String mime = TransferFiles.mimeType((Context)this, source);
                String digest = TransferFiles.sha256((Context)this, source);
                if (this.cancelledTransfers.containsKey(id)) {
                    this.cancelledTransfers.remove(id);
                    return;
                }
                TransferRequest request = new TransferRequest(id, peer, source, name, mime, size, digest);
                Socket socket = new Socket(peer.getAddress(), peer.getPort());
                socket.setSoTimeout(120000);
                this.activeSockets.put(id, socket);
                this.handleConnection(socket, true, request);
            }
            catch (Throwable error) {
                if (!this.cancelledTransfers.containsKey(id)) {
                    this.publishProgress(new TransferProgress(id, TransferProgress.Direction.SEND, "", 0L, 0L, TransferProgress.State.FAILED, error.getMessage()));
                }
                this.cancelledTransfers.remove(id);
            }
        });
    }

    public void cancelTransfer(String id) {
        if (id == null) {
            return;
        }
        this.cancelledTransfers.put(id, true);
        Socket socket = this.activeSockets.remove(id);
        if (socket != null) {
            try {
                socket.close();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        this.publishProgress(new TransferProgress(id, TransferProgress.Direction.SEND, "", 0L, 0L, TransferProgress.State.CANCELLED, null));
    }

    public void confirmPairing(String peerId, boolean accepted) {
        PendingPairing pending = this.pendingPairings.get(peerId);
        if (pending != null) {
            pending.accepted.set(accepted);
            pending.latch.countDown();
        }
    }

    public void revokePeer(String peerId) {
        Peer peer;
        if (peerId != null) {
            this.pairings.revoke(peerId);
        }
        if ((peer = this.peers.get(peerId)) != null) {
            this.peers.put(peerId, peer.withPaired(false));
            this.notifyPeers();
        }
    }

    private void acceptLoop() {
        while (this.available && this.serverSocket != null) {
            try {
                Socket socket = this.serverSocket.accept();
                socket.setSoTimeout(120000);
                this.workers.execute(() -> this.handleConnection(socket, false, null));
            }
            catch (SocketTimeoutException socket) {
            }
            catch (IOException error) {
                if (!this.available) continue;
                Log.w((String)TAG, (String)"Accept loop stopped", (Throwable)error);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void handleConnection(Socket socket, boolean outgoing, TransferRequest request) {
        String transferId = request == null ? null : request.getId();
        try (Socket connection = socket;
             DataInputStream in = new DataInputStream(connection.getInputStream());
             DataOutputStream out = new DataOutputStream(connection.getOutputStream());){
            String localFingerprint = this.identity.fingerprint();
            byte[] localCertificate = this.identity.certificate().getEncoded();
            TransferProtocol.writeFrame(out, (byte)1, TransferProtocol.hello(this.identity.deviceId(), this.identity.deviceName(), localFingerprint, localCertificate));
            TransferProtocol.Frame helloFrame = TransferProtocol.readFrame(in);
            if (helloFrame.type != 1) {
                throw new IOException("Missing HELLO");
            }
            TransferProtocol.Hello hello = TransferProtocol.readHello(helloFrame.payload);
            X509Certificate peerCertificate = (X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(hello.certificate));
            String peerFingerprint = IdentityStore.hex(MessageDigest.getInstance("SHA-256").digest(hello.certificate));
            String peerId = IdentityStore.hex(MessageDigest.getInstance("SHA-256").digest(peerCertificate.getPublicKey().getEncoded()));
            if (!peerFingerprint.equalsIgnoreCase(hello.fingerprint) || !peerId.equals(hello.id)) {
                Log.w((String)TAG, (String)("Peer identity mismatch id=" + hello.id + " calculatedId=" + peerId + " fingerprint=" + hello.fingerprint + " calculatedFingerprint=" + peerFingerprint));
                throw new IOException("Peer identity mismatch");
            }
            if (this.pairings.isKnown(hello.id) && !this.pairings.isPaired(hello.id, peerFingerprint)) {
                throw new IOException("Paired peer certificate changed");
            }
            Peer advertisedPeer = this.peers.get(hello.id);
            Peer peer = advertisedPeer == null ? new Peer(hello.id, hello.name, connection.getInetAddress(), request == null ? connection.getPort() : request.getPeer().getPort(), this.pairings.isPaired(hello.id, peerFingerprint)) : advertisedPeer.withPaired(this.pairings.isPaired(hello.id, peerFingerprint));
            this.peers.put(hello.id, peer);
            this.notifyPeers();
            byte[] localNonce = new byte[32];
            new SecureRandom().nextBytes(localNonce);
            TransferProtocol.writeFrame(out, (byte)2, TransferProtocol.challenge(localNonce));
            TransferProtocol.Frame challengeFrame = TransferProtocol.readFrame(in);
            if (challengeFrame.type != 2) {
                throw new IOException("Missing challenge");
            }
            byte[] remoteNonce = TransferProtocol.readChallenge(challengeFrame.payload);
            String code = IdentityStore.pairingCode(localFingerprint, peerFingerprint, localNonce, remoteNonce);
            if (!this.pairings.isPaired(peer.getId(), peerFingerprint)) {
                if (!this.awaitPairing(peer, code)) {
                    throw new IOException("Pairing was not confirmed");
                }
                this.pairings.pair(peer.getId(), peer.getName(), peerFingerprint);
                peer = peer.withPaired(true);
                this.peers.put(peer.getId(), peer);
                this.notifyPeers();
            }
            if (outgoing) {
                this.sendOffer(connection, in, out, request);
            } else {
                this.receiveOffer(connection, in, out, peer);
            }
        }
        catch (Throwable error) {
            Log.w((String)TAG, (String)"Transfer connection failed", (Throwable)error);
            if (transferId != null && !this.cancelledTransfers.containsKey(transferId)) {
                this.publishProgress(new TransferProgress(transferId, TransferProgress.Direction.SEND, request.getName(), 0L, request.getSize(), TransferProgress.State.FAILED, error.getMessage()));
            }
        }
        finally {
            if (transferId != null) {
                this.activeSockets.remove(transferId);
                this.cancelledTransfers.remove(transferId);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private boolean awaitPairing(Peer peer, String code) {
        PendingPairing pending = new PendingPairing();
        this.pendingPairings.put(peer.getId(), pending);
        this.notifyPairing(peer, code);
        try {
            boolean bl = pending.latch.await(120L, TimeUnit.SECONDS) && pending.accepted.get();
            return bl;
        }
        catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            boolean bl = false;
            return bl;
        }
        finally {
            this.pendingPairings.remove(peer.getId(), pending);
        }
    }

    private void sendOffer(Socket socket, DataInputStream in, DataOutputStream out, TransferRequest request) throws Exception {
        this.publishProgress(new TransferProgress(request.getId(), TransferProgress.Direction.SEND, request.getName(), 0L, request.getSize(), TransferProgress.State.WAITING, null));
        TransferProtocol.writeFrame(out, (byte)3, TransferProtocol.offer(request.getId(), request.getName(), request.getMimeType(), request.getSize(), request.getSha256()));
        TransferProtocol.Frame response = TransferProtocol.readFrame(in);
        if (response.type != 4 || !request.getId().equals(TransferProtocol.readTransferId(response.payload))) {
            throw new IOException("Receiver rejected the file");
        }
        long sent = 0L;
        try (InputStream input = TransferFiles.open((Context)this, request.getSource());){
            int count;
            byte[] buffer = new byte[65536];
            while ((count = input.read(buffer)) != -1) {
                TransferProtocol.writeFrame(out, (byte)6, TransferProtocol.data(request.getId(), sent, buffer, count));
                this.publishProgress(new TransferProgress(request.getId(), TransferProgress.Direction.SEND, request.getName(), sent += (long)count, request.getSize(), TransferProgress.State.TRANSFERRING, null));
            }
        }
        if (sent != request.getSize()) {
            throw new IOException("Source changed during transfer");
        }
        TransferProtocol.writeFrame(out, (byte)7, TransferProtocol.transferId(request.getId()));
        TransferProtocol.Frame complete = TransferProtocol.readFrame(in);
        if (complete.type != 7 || !request.getId().equals(TransferProtocol.readTransferId(complete.payload))) {
            throw new IOException("Receiver did not verify the file");
        }
        this.publishProgress(new TransferProgress(request.getId(), TransferProgress.Direction.SEND, request.getName(), sent, request.getSize(), TransferProgress.State.COMPLETE, null));
    }

    private void receiveOffer(Socket socket, DataInputStream in, DataOutputStream out, Peer peer) throws Exception {
        DocumentFile tree;
        TransferProtocol.Frame frame = TransferProtocol.readFrame(in);
        if (frame.type != 3) {
            throw new IOException("Missing file offer");
        }
        TransferProtocol.Offer offer = TransferProtocol.readOffer(frame.payload);
        Uri destinationUri = this.getDestinationTree();
        DocumentFile documentFile = tree = destinationUri == null ? null : DocumentFile.fromTreeUri((Context)this, (Uri)destinationUri);
        if (tree == null || !tree.canWrite()) {
            TransferProtocol.writeFrame(out, (byte)5, TransferProtocol.transferId(offer.id));
            throw new IOException("Choose a destination folder first");
        }
        DocumentFile temporary = TransferFiles.createTemp((Context)this, destinationUri, offer.name, offer.mime);
        if (temporary == null) {
            throw new IOException("Unable to create destination file");
        }
        try {
            MessageDigest digest;
            long received;
            block20: {
                TransferProtocol.writeFrame(out, (byte)4, TransferProtocol.transferId(offer.id));
                this.publishProgress(new TransferProgress(offer.id, TransferProgress.Direction.RECEIVE, offer.name, 0L, offer.size, TransferProgress.State.TRANSFERRING, null));
                received = 0L;
                digest = MessageDigest.getInstance("SHA-256");
                try (OutputStream output = this.getContentResolver().openOutputStream(temporary.getUri());){
                    TransferProtocol.Frame next;
                    if (output == null) {
                        throw new IOException("Unable to open destination");
                    }
                    while (true) {
                        next = TransferProtocol.readFrame(in);
                        if (next.type != 6) break;
                        TransferProtocol.DataChunk chunk = TransferProtocol.readData(next.payload);
                        if (!offer.id.equals(chunk.id) || chunk.offset != received) {
                            throw new IOException("Invalid data offset");
                        }
                        if (received + (long)chunk.data.length > offer.size) {
                            throw new IOException("Too much data");
                        }
                        output.write(chunk.data);
                        digest.update(chunk.data);
                        this.publishProgress(new TransferProgress(offer.id, TransferProgress.Direction.RECEIVE, offer.name, received += (long)chunk.data.length, offer.size, TransferProgress.State.TRANSFERRING, null));
                    }
                    if (next.type == 7) {
                        if (!offer.id.equals(TransferProtocol.readTransferId(next.payload))) {
                            throw new IOException("Invalid completion");
                        }
                        break block20;
                    }
                    if (next.type == 8) {
                        throw new IOException("Sender cancelled transfer");
                    }
                    throw new IOException("Unexpected transfer frame");
                }
            }
            String actual = IdentityStore.hex(digest.digest());
            if (received != offer.size || !actual.equalsIgnoreCase(offer.sha256)) {
                throw new IOException("File verification failed");
            }
            String finalName = TransferFiles.uniqueName(tree, offer.name);
            if (!temporary.renameTo(finalName)) {
                throw new IOException("Unable to finalize received file");
            }
            TransferProtocol.writeFrame(out, (byte)7, TransferProtocol.transferId(offer.id));
            this.publishProgress(new TransferProgress(offer.id, TransferProgress.Direction.RECEIVE, finalName, received, offer.size, TransferProgress.State.COMPLETE, null));
        }
        catch (Exception error) {
            temporary.delete();
            throw error;
        }
    }

    private void startNsd() {
        try {
            WifiManager wifi = (WifiManager)this.getSystemService("wifi");
            if (wifi != null) {
                this.multicastLock = wifi.createMulticastLock("imageserver-nsd");
                this.multicastLock.setReferenceCounted(false);
                this.multicastLock.acquire();
            }
            this.registeredService = new NsdServiceInfo();
            this.registeredService.setServiceName("ImageServer-" + this.deviceId.substring(0, 8));
            this.registeredService.setServiceType(SERVICE_TYPE);
            this.registeredService.setPort(this.serverSocket.getLocalPort());
            this.registeredService.setAttribute("id", this.identity.deviceId());
            this.registeredService.setAttribute("name", this.identity.deviceName());
            this.registeredService.setAttribute("v", String.valueOf(1));
            this.registrationListener = new NsdManager.RegistrationListener(){

                public void onServiceRegistered(NsdServiceInfo info) {
                    TransferService.this.registeredService = info;
                }

                public void onRegistrationFailed(NsdServiceInfo info, int errorCode) {
                    TransferService.this.notifyError("Peer advertising failed: " + errorCode);
                }

                public void onServiceUnregistered(NsdServiceInfo info) {
                }

                public void onUnregistrationFailed(NsdServiceInfo info, int errorCode) {
                }
            };
            this.nsdManager.registerService(this.registeredService, 1, this.registrationListener);
            this.discoveryListener = new NsdManager.DiscoveryListener(){

                public void onDiscoveryStarted(String serviceType) {
                    Log.i((String)TransferService.TAG, (String)("NSD discovery started for " + serviceType));
                }

                public void onServiceFound(NsdServiceInfo serviceInfo) {
                    Log.i((String)TransferService.TAG, (String)("NSD service found: " + serviceInfo));
                    if (!TransferService.this.sameServiceType(serviceInfo.getServiceType())) {
                        return;
                    }
                    TransferService.this.nsdManager.resolveService(serviceInfo, new NsdManager.ResolveListener(){

                        public void onResolveFailed(NsdServiceInfo info, int errorCode) {
                            Log.w((String)TransferService.TAG, (String)("NSD resolve failed for " + info.getServiceName() + ": " + errorCode));
                        }

                        public void onServiceResolved(NsdServiceInfo info) {
                            String id;
                            if (TransferService.this.registeredService != null && TransferService.this.registeredService.getServiceName().equals(info.getServiceName())) {
                                return;
                            }
                            Map attributes = info.getAttributes();
                            if (attributes == null) {
                                attributes = Collections.emptyMap();
                            }
                            byte[] idBytes = (byte[])attributes.get("id");
                            byte[] nameBytes = (byte[])attributes.get("name");
                            String string = id = idBytes == null ? "nsd:" + info.getServiceName() : new String(idBytes, StandardCharsets.UTF_8);
                            if (TransferService.this.deviceId.equals(id) || info.getHost() == null) {
                                return;
                            }
                            String name = nameBytes == null ? info.getServiceName() : new String(nameBytes, StandardCharsets.UTF_8);
                            String fingerprint = TransferService.this.pairings.all().get(id);
                            String previousId = TransferService.this.servicePeerIds.put(info.getServiceName(), id);
                            if (previousId != null && !previousId.equals(id)) {
                                TransferService.this.peers.remove(previousId);
                            }
                            TransferService.this.peers.put(id, new Peer(id, name, info.getHost(), info.getPort(), fingerprint != null));
                            Log.i((String)TransferService.TAG, (String)("NSD peer resolved: " + name + " at " + info.getHost() + ":" + info.getPort()));
                            TransferService.this.notifyPeers();
                        }
                    });
                }

                public void onServiceLost(NsdServiceInfo serviceInfo) {
                    String id = (String)TransferService.this.servicePeerIds.remove(serviceInfo.getServiceName());
                    if (id != null && !TransferService.this.servicePeerIds.containsValue(id)) {
                        TransferService.this.peers.remove(id);
                    }
                    TransferService.this.notifyPeers();
                }

                public void onDiscoveryStopped(String serviceType) {
                }

                public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                    TransferService.this.notifyError("Peer discovery failed: " + errorCode);
                }

                public void onStopDiscoveryFailed(String serviceType, int errorCode) {
                }
            };
            this.nsdManager.discoverServices(SERVICE_TYPE, 1, this.discoveryListener);
        }
        catch (Throwable error) {
            Log.e((String)TAG, (String)"Unable to start NSD", (Throwable)error);
            this.notifyError("Could not discover peers: " + error.getMessage());
        }
    }

    private boolean sameServiceType(String value) {
        if (value == null) {
            return false;
        }
        return SERVICE_TYPE.equals(value) || "_imageserver._tcp.".equals(value);
    }

    private void notifyAvailability(boolean value) {
        this.mainHandler.post(() -> {
            for (TransferObserver observer : this.observers) {
                observer.onAvailabilityChanged(value);
            }
        });
    }

    private void notifyPeers() {
        List<Peer> values = this.getPeers();
        this.mainHandler.post(() -> {
            for (TransferObserver observer : this.observers) {
                observer.onPeersChanged(values);
            }
        });
    }

    private void notifyPeersTo(TransferObserver observer) {
        List<Peer> values = this.getPeers();
        this.mainHandler.post(() -> observer.onPeersChanged(values));
    }

    private void notifyPairing(Peer peer, String code) {
        this.mainHandler.post(() -> {
            for (TransferObserver observer : this.observers) {
                observer.onPairingRequested(peer, code);
            }
        });
    }

    private void publishProgress(TransferProgress progress) {
        this.mainHandler.post(() -> {
            this.updateNotification(progress);
            for (TransferObserver observer : this.observers) {
                observer.onTransferUpdated(progress);
            }
        });
    }

    private void notifyError(String message) {
        this.mainHandler.post(() -> {
            for (TransferObserver observer : this.observers) {
                observer.onError(message);
            }
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, (CharSequence)"File transfer availability", 2);
            ((NotificationManager)this.getSystemService("notification")).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent((Context)this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity((Context)this, (int)0, (Intent)open, (int)0xC000000);
        Intent stop = new Intent((Context)this, TransferService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService((Context)this, (int)1, (Intent)stop, (int)0xC000000);
        return new NotificationCompat.Builder((Context)this, CHANNEL_ID).setSmallIcon(R.mipmap.ic_launcher).setContentTitle((CharSequence)"ImageServer").setContentText((CharSequence)text).setContentIntent(pending).setOngoing(true).addAction(0, (CharSequence)"Stop", stopPending).build();
    }

    private void updateNotification(TransferProgress progress) {
        String text = progress.getName().isEmpty() ? "Available for file transfers" : progress.getName() + " " + progress.getCompleted() + "/" + progress.getTotal();
        ((NotificationManager)this.getSystemService("notification")).notify(41, this.buildNotification(text));
    }

    public final class LocalBinder
    extends Binder {
        public TransferService getService() {
            return TransferService.this;
        }
    }

    private static final class PendingPairing {
        final CountDownLatch latch = new CountDownLatch(1);
        final AtomicBoolean accepted = new AtomicBoolean(false);

        private PendingPairing() {
        }
    }
}
