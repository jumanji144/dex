package com.example.imageserver.transfer;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;
import java.util.Map;

public final class PairingStore {
    private static final String PREFS = "transfer_pairings";
    private final SharedPreferences preferences;

    public PairingStore(Context context) {
        this.preferences = context.getApplicationContext().getSharedPreferences(PREFS, 0);
    }

    public boolean isPaired(String id, String fingerprint) {
        return fingerprint != null && fingerprint.equals(this.preferences.getString("fingerprint_" + id, null));
    }

    public boolean isKnown(String id) {
        return this.preferences.contains("fingerprint_" + id);
    }

    public void pair(String id, String name, String fingerprint) {
        this.preferences.edit().putString("fingerprint_" + id, fingerprint).putString("name_" + id, name).apply();
    }

    public void revoke(String id) {
        this.preferences.edit().remove("fingerprint_" + id).remove("name_" + id).apply();
    }

    public Map<String, String> all() {
        HashMap<String, String> result = new HashMap<String, String>();
        for (Map.Entry entry : this.preferences.getAll().entrySet()) {
            if (!((String)entry.getKey()).startsWith("fingerprint_")) continue;
            result.put(((String)entry.getKey()).substring("fingerprint_".length()), String.valueOf(entry.getValue()));
        }
        return result;
    }
}
