package com.example.imageserver.transfer;

import com.example.imageserver.transfer.Peer;
import com.example.imageserver.transfer.TransferProgress;
import java.util.List;

public interface TransferObserver {
    public void onAvailabilityChanged(boolean var1);

    public void onPeersChanged(List<Peer> var1);

    public void onPairingRequested(Peer var1, String var2);

    public void onTransferUpdated(TransferProgress var1);

    public void onError(String var1);
}
