package com.example.imageserver.transfer;

public final class TransferProgress {
    private final String id;
    private final Direction direction;
    private final String name;
    private final long completed;
    private final long total;
    private final State state;
    private final String error;

    public TransferProgress(String id, Direction direction, String name, long completed, long total, State state, String error) {
        this.id = id;
        this.direction = direction;
        this.name = name;
        this.completed = completed;
        this.total = total;
        this.state = state;
        this.error = error;
    }

    public String getId() {
        return this.id;
    }

    public Direction getDirection() {
        return this.direction;
    }

    public String getName() {
        return this.name;
    }

    public long getCompleted() {
        return this.completed;
    }

    public long getTotal() {
        return this.total;
    }

    public State getState() {
        return this.state;
    }

    public String getError() {
        return this.error;
    }

    public static enum Direction {
        SEND,
        RECEIVE;

    }

    public static enum State {
        PREPARING,
        WAITING,
        TRANSFERRING,
        COMPLETE,
        FAILED,
        CANCELLED;

    }
}
