package com.example.imageserver.transfer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public final class TransferProtocol {
    public static final int VERSION = 1;
    public static final int MAX_FRAME = 0x100000;
    public static final int CHUNK_SIZE = 65536;
    public static final byte HELLO = 1;
    public static final byte CHALLENGE = 2;
    public static final byte OFFER = 3;
    public static final byte ACCEPT = 4;
    public static final byte REJECT = 5;
    public static final byte DATA = 6;
    public static final byte COMPLETE = 7;
    public static final byte CANCEL = 8;
    public static final byte ERROR = 9;

    private TransferProtocol() {
    }

    public static void writeFrame(DataOutputStream out, byte type, byte[] payload) throws IOException {
        if (payload == null) {
            payload = new byte[]{};
        }
        if (payload.length > 1048575) {
            throw new IOException("Frame too large");
        }
        out.writeInt(payload.length + 1);
        out.writeByte(type);
        out.write(payload);
        out.flush();
    }

    public static Frame readFrame(DataInputStream in) throws IOException {
        int length = in.readInt();
        if (length < 1 || length > 0x100000) {
            throw new IOException("Invalid frame length");
        }
        byte type = in.readByte();
        byte[] payload = new byte[length - 1];
        in.readFully(payload);
        return new Frame(type, payload);
    }

    public static byte[] hello(String id, String name, String fingerprint, byte[] certificate) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(1);
        TransferProtocol.writeString(out, id);
        TransferProtocol.writeString(out, name);
        TransferProtocol.writeString(out, fingerprint);
        if (certificate.length > 16384) {
            throw new IOException("Certificate too large");
        }
        out.writeInt(certificate.length);
        out.write(certificate);
        return bytes.toByteArray();
    }

    public static Hello readHello(byte[] payload) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(payload));
        int version = in.readInt();
        if (version != 1) {
            throw new IOException("Unsupported protocol version");
        }
        String id = TransferProtocol.readString(in);
        String name = TransferProtocol.readString(in);
        String fingerprint = TransferProtocol.readString(in);
        int certificateLength = in.readInt();
        if (certificateLength < 1 || certificateLength > 16384 || certificateLength > in.available()) {
            throw new IOException("Invalid certificate");
        }
        byte[] certificate = new byte[certificateLength];
        in.readFully(certificate);
        return new Hello(id, name, fingerprint, certificate);
    }

    public static byte[] challenge(byte[] nonce) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(nonce.length);
        out.write(nonce);
        return bytes.toByteArray();
    }

    public static byte[] readChallenge(byte[] payload) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(payload));
        int length = in.readInt();
        if (length != 32) {
            throw new IOException("Invalid challenge");
        }
        byte[] nonce = new byte[length];
        in.readFully(nonce);
        return nonce;
    }

    public static byte[] offer(String id, String name, String mime, long size, String sha256) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        TransferProtocol.writeString(out, id);
        TransferProtocol.writeString(out, name);
        TransferProtocol.writeString(out, mime);
        out.writeLong(size);
        TransferProtocol.writeString(out, sha256);
        return bytes.toByteArray();
    }

    public static Offer readOffer(byte[] payload) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(payload));
        String id = TransferProtocol.readString(in);
        String name = TransferProtocol.readString(in);
        String mime = TransferProtocol.readString(in);
        long size = in.readLong();
        String sha256 = TransferProtocol.readString(in);
        if (size < 0L || size > 0x3FFFFFFFFFFFFFFFL) {
            throw new IOException("Invalid file size");
        }
        if (name.length() == 0 || name.length() > 512) {
            throw new IOException("Invalid file name");
        }
        return new Offer(id, name, mime, size, sha256);
    }

    public static byte[] transferId(String id) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        TransferProtocol.writeString(out, id);
        return bytes.toByteArray();
    }

    public static String readTransferId(byte[] payload) throws IOException {
        return TransferProtocol.readString(new DataInputStream(new ByteArrayInputStream(payload)));
    }

    public static byte[] data(String id, long offset, byte[] chunk, int length) throws IOException {
        if (length < 0 || length > 65536 || length > chunk.length) {
            throw new IOException("Invalid chunk");
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(length + 64);
        DataOutputStream out = new DataOutputStream(bytes);
        TransferProtocol.writeString(out, id);
        out.writeLong(offset);
        out.writeInt(length);
        out.write(chunk, 0, length);
        return bytes.toByteArray();
    }

    public static DataChunk readData(byte[] payload) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(payload));
        String id = TransferProtocol.readString(in);
        long offset = in.readLong();
        int length = in.readInt();
        if (offset < 0L || length < 0 || length > 65536 || length > in.available()) {
            throw new IOException("Invalid data chunk");
        }
        byte[] chunk = new byte[length];
        in.readFully(chunk);
        return new DataChunk(id, offset, chunk);
    }

    public static void writeString(DataOutputStream out, String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > 65536) {
            throw new IOException("String too long");
        }
        out.writeInt(bytes.length);
        out.write(bytes);
    }

    public static String readString(DataInputStream in) throws IOException {
        int length = in.readInt();
        if (length < 0 || length > 65536 || length > in.available()) {
            throw new IOException("Invalid string");
        }
        byte[] bytes = new byte[length];
        in.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    public static final class Frame {
        public final byte type;
        public final byte[] payload;

        Frame(byte type, byte[] payload) {
            this.type = type;
            this.payload = payload;
        }
    }

    public static final class Hello {
        public final String id;
        public final String name;
        public final String fingerprint;
        public final byte[] certificate;

        Hello(String id, String name, String fingerprint, byte[] certificate) {
            this.id = id;
            this.name = name;
            this.fingerprint = fingerprint;
            this.certificate = certificate;
        }
    }

    public static final class Offer {
        public final String id;
        public final String name;
        public final String mime;
        public final String sha256;
        public final long size;

        Offer(String id, String name, String mime, long size, String sha256) {
            this.id = id;
            this.name = name;
            this.mime = mime;
            this.size = size;
            this.sha256 = sha256;
        }
    }

    public static final class DataChunk {
        public final String id;
        public final long offset;
        public final byte[] data;

        DataChunk(String id, long offset, byte[] data) {
            this.id = id;
            this.offset = offset;
            this.data = data;
        }
    }
}
