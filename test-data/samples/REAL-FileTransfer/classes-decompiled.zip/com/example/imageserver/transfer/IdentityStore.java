package com.example.imageserver.transfer;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import java.io.ByteArrayOutputStream;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Arrays;
import java.util.Locale;

public final class IdentityStore {
    private static final String KEY_ALIAS = "imageserver-transfer-identity-rsa-v3";
    private static final String LEGACY_EC_ALIAS = "imageserver-transfer-identity";
    private static final String LEGACY_RSA_ALIAS = "imageserver-transfer-identity-rsa-v2";
    private static final String PREFS = "transfer_identity";
    private final Context context;
    private final SharedPreferences preferences;

    public IdentityStore(Context context) {
        this.context = context.getApplicationContext();
        this.preferences = this.context.getSharedPreferences(PREFS, 0);
    }

    public synchronized void ensureIdentity() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(LEGACY_EC_ALIAS)) {
            store.deleteEntry(LEGACY_EC_ALIAS);
        }
        if (store.containsAlias(LEGACY_RSA_ALIAS)) {
            store.deleteEntry(LEGACY_RSA_ALIAS);
        }
        if (!store.containsAlias(KEY_ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
            generator.initialize((AlgorithmParameterSpec)new KeyGenParameterSpec.Builder(KEY_ALIAS, 15).setKeySize(2048).setDigests(new String[]{"SHA-256", "SHA-512"}).setSignaturePaddings(new String[]{"PKCS1"}).setEncryptionPaddings(new String[]{"NoPadding", "PKCS1Padding"}).setRandomizedEncryptionRequired(false).build());
            generator.generateKeyPair();
        }
        if (!this.preferences.contains("name")) {
            this.preferences.edit().putString("name", Build.MODEL == null ? "Android device" : Build.MODEL).apply();
        }
    }

    public X509Certificate certificate() throws Exception {
        this.ensureIdentity();
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        return (X509Certificate)store.getCertificate(KEY_ALIAS);
    }

    public String fingerprint() throws Exception {
        return IdentityStore.hex(MessageDigest.getInstance("SHA-256").digest(this.certificate().getEncoded()));
    }

    public String deviceId() throws Exception {
        return IdentityStore.hex(MessageDigest.getInstance("SHA-256").digest(this.certificate().getPublicKey().getEncoded()));
    }

    public String deviceName() {
        return this.preferences.getString("name", "Android device");
    }

    public void setDeviceName(String name) {
        String clean;
        String string = clean = name == null ? "" : name.trim();
        if (clean.length() == 0) {
            clean = "Android device";
        }
        if (clean.length() > 64) {
            clean = clean.substring(0, 64);
        }
        this.preferences.edit().putString("name", clean).apply();
    }

    public static byte[] sessionTranscript(String firstFingerprint, String secondFingerprint, byte[] firstNonce, byte[] secondNonce) throws Exception {
        Object[] fingerprints = new String[]{firstFingerprint, secondFingerprint};
        Arrays.sort(fingerprints);
        byte[][] nonces = new byte[][]{firstNonce, secondNonce};
        Arrays.sort(nonces, (a, b) -> IdentityStore.compareBytes(a, b));
        ByteArrayOutputStream input = new ByteArrayOutputStream();
        input.write(((String)fingerprints[0]).getBytes("UTF-8"));
        input.write(((String)fingerprints[1]).getBytes("UTF-8"));
        input.write(nonces[0]);
        input.write(nonces[1]);
        input.write("ImageServer/v1".getBytes("UTF-8"));
        return MessageDigest.getInstance("SHA-256").digest(input.toByteArray());
    }

    public static String pairingCode(String firstFingerprint, String secondFingerprint, byte[] firstNonce, byte[] secondNonce) throws Exception {
        Object[] fingerprints = new String[]{firstFingerprint, secondFingerprint};
        Arrays.sort(fingerprints);
        byte[][] nonces = new byte[][]{firstNonce, secondNonce};
        Arrays.sort(nonces, (a, b) -> IdentityStore.compareBytes(a, b));
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(IdentityStore.sessionTranscript((String)fingerprints[0], (String)fingerprints[1], nonces[0], nonces[1]));
        int number = (digest[0] & 0xFF) << 16 | (digest[1] & 0xFF) << 8 | digest[2] & 0xFF;
        return String.format(Locale.US, "%06d", number % 1000000);
    }

    private static int compareBytes(byte[] a, byte[] b) {
        for (int i = 0; i < Math.min(a.length, b.length); ++i) {
            int comparison = Byte.compare(a[i], b[i]);
            if (comparison == 0) continue;
            return comparison;
        }
        return Integer.compare(a.length, b.length);
    }

    public static String hex(byte[] bytes) {
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            result.append(String.format(Locale.US, "%02x", value & 0xFF));
        }
        return result.toString();
    }
}
