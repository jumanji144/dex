package com.example.imageserver;

import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.example.imageserver.R;
import com.example.imageserver.transfer.Peer;
import com.example.imageserver.transfer.TransferObserver;
import com.example.imageserver.transfer.TransferProgress;
import com.example.imageserver.transfer.TransferService;
import java.util.List;

public class MainActivity
extends AppCompatActivity {
    private TransferService service;
    private boolean bound;
    private Peer selectedPeer;
    private LinearLayout peerList;
    private Button availabilityButton;
    private Button uploadButton;
    private Button forgetButton;
    private TextView folderText;
    private TextView statusText;
    private final TransferObserver observer = new TransferObserver(){

        @Override
        public void onAvailabilityChanged(boolean available) {
            MainActivity.this.availabilityButton.setText((CharSequence)(available ? "Available: ON" : "Available: OFF"));
            MainActivity.this.availabilityButton.setEnabled(true);
        }

        @Override
        public void onPeersChanged(List<Peer> peers) {
            MainActivity.this.renderPeers(peers);
        }

        @Override
        public void onPairingRequested(Peer peer, String code) {
            new AlertDialog.Builder((Context)MainActivity.this).setTitle((CharSequence)"Confirm device").setMessage((CharSequence)("Connect to " + peer.getName() + "?\n\nBoth devices must show:\n" + code)).setPositiveButton((CharSequence)"Trust", (dialog, which) -> MainActivity.this.service.confirmPairing(peer.getId(), true)).setNegativeButton((CharSequence)"Reject", (dialog, which) -> MainActivity.this.service.confirmPairing(peer.getId(), false)).setOnCancelListener(dialog -> MainActivity.this.service.confirmPairing(peer.getId(), false)).show();
        }

        @Override
        public void onTransferUpdated(TransferProgress progress) {
            String prefix = progress.getDirection() == TransferProgress.Direction.SEND ? "Sending " : "Receiving ";
            String message = progress.getName().isEmpty() ? progress.getState().name() : prefix + progress.getName() + " " + progress.getCompleted() + "/" + progress.getTotal();
            MainActivity.this.statusText.setText((CharSequence)message);
            if (progress.getState() == TransferProgress.State.COMPLETE) {
                Toast.makeText((Context)MainActivity.this, (CharSequence)"Transfer complete", (int)0).show();
            } else if (progress.getState() == TransferProgress.State.FAILED) {
                Toast.makeText((Context)MainActivity.this, (CharSequence)("Transfer failed: " + progress.getError()), (int)1).show();
            }
        }

        @Override
        public void onError(String message) {
            MainActivity.this.statusText.setText((CharSequence)message);
            Toast.makeText((Context)MainActivity.this, (CharSequence)message, (int)1).show();
        }
    };
    private final ServiceConnection connection = new ServiceConnection(){

        public void onServiceConnected(ComponentName name, IBinder binder) {
            MainActivity.this.service = ((TransferService.LocalBinder)binder).getService();
            MainActivity.this.bound = true;
            MainActivity.this.service.registerObserver(MainActivity.this.observer);
            Uri destination = MainActivity.this.service.getDestinationTree();
            MainActivity.this.folderText.setText((CharSequence)(destination == null ? "Destination: not selected" : "Destination selected"));
            MainActivity.this.availabilityButton.setText((CharSequence)(MainActivity.this.service.isAvailable() ? "Available: ON" : "Available: OFF"));
        }

        public void onServiceDisconnected(ComponentName name) {
            MainActivity.this.bound = false;
            MainActivity.this.service = null;
        }
    };
    private final ActivityResultLauncher<Intent> filePicker = this.registerForActivityResult((ActivityResultContract)new ActivityResultContracts.StartActivityForResult(), result -> {
        if (result.getResultCode() == -1 && result.getData() != null && this.selectedPeer != null && this.service != null) {
            this.service.sendFile(this.selectedPeer, result.getData().getData());
        }
    });
    private final ActivityResultLauncher<Intent> folderPicker = this.registerForActivityResult((ActivityResultContract)new ActivityResultContracts.StartActivityForResult(), result -> {
        Uri uri;
        if (result.getResultCode() == -1 && result.getData() != null && this.service != null && (uri = result.getData().getData()) != null) {
            this.service.setDestinationTree(uri);
            this.folderText.setText((CharSequence)"Destination selected");
        }
    });

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_main);
        this.availabilityButton = (Button)this.findViewById(R.id.availabilityButton);
        this.uploadButton = (Button)this.findViewById(R.id.uploadButton);
        this.forgetButton = (Button)this.findViewById(R.id.forgetButton);
        this.folderText = (TextView)this.findViewById(R.id.folderText);
        this.statusText = (TextView)this.findViewById(R.id.statusText);
        this.peerList = (LinearLayout)this.findViewById(R.id.peerList);
        this.uploadButton.setEnabled(false);
        this.forgetButton.setEnabled(false);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.POST_NOTIFICATIONS") != 0) {
            this.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        }
    }

    protected void onStart() {
        super.onStart();
        this.bindService(new Intent((Context)this, TransferService.class), this.connection, 1);
    }

    protected void onStop() {
        if (this.bound && this.service != null) {
            this.service.unregisterObserver(this.observer);
        }
        if (this.bound) {
            this.unbindService(this.connection);
        }
        this.bound = false;
        super.onStop();
    }

    public void toggleAvailability(View view) {
        if (this.service == null) {
            return;
        }
        if (this.service.isAvailable()) {
            this.service.stopAvailability();
            this.stopService(new Intent((Context)this, TransferService.class));
        } else {
            ContextCompat.startForegroundService((Context)this, (Intent)new Intent((Context)this, TransferService.class).setAction("com.example.imageserver.transfer.START"));
        }
    }

    public void chooseFolder(View view) {
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
        intent.addFlags(67);
        this.folderPicker.launch((Object)intent);
    }

    public void chooseFile(View view) {
        if (this.service == null || this.selectedPeer == null) {
            Toast.makeText((Context)this, (CharSequence)"Select an available peer first", (int)0).show();
            return;
        }
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("*/*");
        this.filePicker.launch((Object)intent);
    }

    public void forgetSelectedPeer(View view) {
        if (this.service != null && this.selectedPeer != null) {
            this.service.revokePeer(this.selectedPeer.getId());
            this.selectedPeer = this.selectedPeer.withPaired(false);
            this.forgetButton.setEnabled(false);
            this.statusText.setText((CharSequence)"Peer trust revoked");
        }
    }

    private void renderPeers(List<Peer> peers) {
        this.peerList.removeAllViews();
        this.selectedPeer = null;
        this.uploadButton.setEnabled(false);
        this.forgetButton.setEnabled(false);
        for (Peer peer : peers) {
            Button button = new Button((Context)this);
            button.setAllCaps(false);
            button.setText((CharSequence)(peer.getName() + (peer.isPaired() ? "  \u2713" : "  (new)")));
            button.setOnClickListener(view -> {
                this.selectedPeer = peer;
                this.uploadButton.setEnabled(true);
                this.forgetButton.setEnabled(peer.isPaired());
                this.statusText.setText((CharSequence)("Selected " + peer.getName()));
            });
            this.peerList.addView((View)button);
        }
        if (peers.isEmpty()) {
            TextView empty = new TextView((Context)this);
            empty.setText((CharSequence)"No ImageServer peers found");
            this.peerList.addView((View)empty);
        }
    }
}
