public class CallSite {
    private final String name;

    public CallSite(String name) {
        this.name = name;
    }

    public String greet(int id) {
        // String concatenation compiles to an invokedynamic call site, whose bootstrap is a method handle.
        return "hello " + name + " #" + id;
    }

    public Runnable task() {
        return () -> System.out.println(greet(1));
    }
}
